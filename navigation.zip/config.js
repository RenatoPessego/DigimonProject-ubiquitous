// config.js
export const API_URL = 'http://193.2.231.173:5000'; 